<nav id="nav">
    <span class="bars">
        <i class="fas fa-bars custom_bars"></i>
    </span>
</nav>
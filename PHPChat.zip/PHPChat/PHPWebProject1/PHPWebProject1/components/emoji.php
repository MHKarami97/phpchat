<div class="emoji">
    <?php

    for($i=1;$i<21;$i++){

        echo "<img src='assets/img/emoji/$i.png' class='emoji_same' />";
    }

    ?>
</div><!--Close emoji-->